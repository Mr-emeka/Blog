<?php
/**
 * The template for displaying featured posts on the front page
 *
 * @package Audioman
 */
?>

<?php
audioman_featured_slider();
